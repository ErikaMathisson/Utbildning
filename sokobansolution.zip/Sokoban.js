﻿
/*   This is the suggested solution to the assignment - an example of how it can be done   */

var currentTileMap;
var container = document.getElementById('sokoban-board');

function Draw(tileMap) {
    if (tileMap != null) {
        currentTileMap = tileMap;
        container.width = currentTileMap[0].length * 32;
    }
    while (container.lastChild) {
        container.removeChild(container.lastChild);
    }
    for (var row = 0; row < currentTileMap.length; row++) {
        var tileRow = document.createElement("div");
        tileRow.classList.add("tile-row");
        for (var cell = 0; cell < currentTileMap[row].length; cell++) {
            var div = document.createElement("div");
            div.id = row + "-" + cell;

            var tileClass = currentTileMap[row][cell];

            div.classList.add("tile");
            if (tileClass == 'W') { div.classList.add(Tiles.Wall); }
            else if (tileClass == ' ') { div.classList.add(Tiles.Space); }
            else if (tileClass == 'G') { div.classList.add(Tiles.Goal); }
            else if (tileClass == 'B') {
                div.classList.add(Tiles.Space);
                var block = {
                    block: initEntity(Entities.Block),
                    position: { x: cell, y: row }
                };
                blocks.push(block);
                div.appendChild(block.block);
            }
            else if (tileClass == 'D') { div.classList.add(Entities.BlockDone); }
            else if (tileClass == 'P') {
                div.classList.add(Tiles.Space);
                player.position.x == -1 ? player.position.x = cell : null;
                player.position.y == -1 ? player.position.y = row : null;
                div.appendChild(player.block);
            }
            else { tileClass = "" }

            tileRow.appendChild(div);
        }
        container.appendChild(tileRow);
    }
}

function Move(entity, direction) {
    var x = entity.position.x;
    var y = entity.position.y;
    switch (direction) {
        case "left":
            x--;
            break;
        case "right":
            x++;
            break;
        case "up":
            y--;
            break;
        case "down":
            y++;
            break;
        default:
            break;
    }

    var isValidMove = false;
    var pushBlock = blocks.filter(function (a) { return a.position.x === x && a.position.y === y })[0];

    if (currentTileMap[y][x] == 'W') {
        return false;
    } else if (pushBlock != null) {
        if (entity === player) {
            if (!Move(pushBlock, direction)) {
                return false;
            }
        } else {
            return false;
        }
    } else {
        if (!(entity === player)) {
            if (currentTileMap[y][x] == 'G') {
                entity.block.className = Entities.BlockDone;
            } else {
                entity.block.className = Entities.Block;
            }
        }
    }

    document.getElementById(y + "-" + x).appendChild(entity.block);
    entity.position.y = y;
    entity.position.x = x;
    return true;
}

function initEntity(className) {
    var div = document.createElement("div");
    var classes = className.split(' ');
    for (var i = 0; i < classes.length; i++) {
        div.classList.add(classes[i]);
    }
    return div;
}

$(document).keydown(function (e) {
    var key = e.which;
    var ar = new Array(37, 38, 39, 40);
    if ($.inArray(key, ar) > -1) {
        switch (key) {
            case 37: { Move(player, "left"); } break;
            case 38: { Move(player, "up"); } break;
            case 39: { Move(player, "right"); } break;
            case 40: { Move(player, "down"); } break;
            default:
                break;
        }
        e.preventDefault();
        return false;
    }
    return true;
});

var player = {
    block: initEntity(Entities.Character),
    position: { x: -1, y: -1 }
}
var blocks = [];

Draw(tileMap01);
